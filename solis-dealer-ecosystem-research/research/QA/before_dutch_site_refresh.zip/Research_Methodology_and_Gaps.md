# Research methodology and remaining gaps

Research cutoff and access date: 3 November 2026, Europe Amsterdam. Prepared for Raja and company leadership.

## Work completed

The workspace was inspected for earlier Solis documents; none was located among available report files. Fresh public research covered Solis World, its EU range and country links, the Netherlands importer/dealer sites, selected German and Romanian routes, Solis USA as a reuse clue, official competitor documentation, industry association material, qualitative forums and original financial disclosures. Independent areas were researched in parallel as requested in the assignment.

Actual public routes included Dutch selector choices, S26 configuration/options and quote form, the effective-dated PDF price list, AgriXpert product/category pages, dealer/service/warranty routes, regional login entry points and public dealer application forms. Forms were inspected without submission. No purchases, accounts, messages to third parties or warranty claims were initiated.

The evidence register contains 67 entries representing 62 original URLs. Duplicate sources retain their research IDs and are grouped by original URL in the report appendix. Verified means direct support from a reviewed source, including explicitly attributed company descriptions. Reported, Inference, Hypothesis and Open question preserve weaker evidence or analytical status. Dates absent from originals are recorded as not stated. A page's upload path is not treated as its effective date.

Material financial figures were taken from ICRA's reproduction of ITL indicators, AGCO's audited annual report, Titan's audited 10-K and reviewed CNH/Deere/Kubota disclosures. Calculations retain reporting entity, year, scope, unit and denominator. No peer percentage is applied to Solis. The workbook contains an independent scenario build, not a Solis forecast.

## Access and evidence limits

- No authenticated Solis or competitor portal was entered. Germany's login and Romania's DMS/IBIZ links establish public entry points only. A company description establishes the US portal claim, not Dutch access.
- Dutch comparison/catalogue and some global pages timed out. A document centre required Google sign-in. The Dutch selector's parsed results contained count/width anomalies requiring live-browser retest before calling them product defects.
- A Solis USA brochure URL returned 404. Indexed text was not promoted into verified evidence.
- Deere originals sometimes returned JavaScript-only bodies or access errors; technical API claims were not treated as verified. Its JD early-access announcement is retained as limited-access Reported evidence.
- Some CNH PDF/course leads were inaccessible. The opened 2016 sustainability report is expressly a historical precedent, not a current process assertion.
- Latest NAEDA proprietary survey results were protected. Only the public survey scope was used; no scores or Dutch/Solis findings were inferred.
- Forum statements have unverified identities and mixed local experiences. They are qualitative signals and do not establish prevalence.
- Full ITL audited statements and FY2026 audited indicators were not obtained. ICRA evidence is classified Reported. A consolidation-scope ambiguity remains between its finance exclusion language and annexure.
- No certified current Dutch registry extract, dealer contract, data-processing agreement, catalogue licence, ERP inventory or real serial/build sample was supplied.
- No actual Solis revenue split, contribution margins, installed base, task time, lead conversion, return rate, adoption, implementation cost or payback was established.

## Material corrections

1. solis.eu is an appliance namesake, excluded from tractor capabilities.
2. “Solis Structures NL” remains unresolved and is not a contracting entity.
3. ITL's Solis B.V. is distinguished from AgriXpert/DIGO; a shared address does not establish common ownership.
4. Existing Dutch selector, configurator, pricing and ecommerce are recognised.
5. Existing regional portal evidence rules out claiming complete portal absence.
6. Stock labels do not prove real-time dealer stock. A warranty form does not establish a complete machine history.
7. Almere and Germany parts references retain their geographic/operational uncertainty.
8. Mitsubishi/Yanmar relationships do not establish fitment or catalogue reuse rights for every tractor.
9. Parts/service peer financial definitions remain separate from Solis and from one another.

## Required validation before investment

Resolve sponsor and legal identity; demonstrate existing private systems and reuse costs; confirm data rights and controllers; observe a proposed six-to-eight-dealer sample; test ten authorised serial-to-part cases; obtain 24 months of ledger-reconciled invoice and workflow records; agree role, approval and exception ownership; measure a bounded pilot before wider rollout. Proposed sample sizes are operational starting points, not representative survey claims.

The illustrative model assumes one eligible parts order per identification request, separates non-labour return cost from productivity time and treats capacity equivalent separately from cash savings. Replace these assumptions with observed denominators and attributable effects.

## File and layout verification

The report has 24 numbered sections, an executive decision page, source references and original visuals. Source IDs are validated against the register. Financial calculations and scenario transitions were checked, including missing values and legitimate zeros. Native Excel was not opened.

The packaged DOCX renderer was attempted and failed because LibreOffice was unavailable. Native Microsoft Word was used to update the contents and export the DOCX to PDF; the resulting PDF was rendered with Poppler for page-by-page review. Final verification results are recorded in the delivery verification note.
