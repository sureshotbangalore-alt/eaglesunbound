import fs from 'node:fs/promises';
import path from 'node:path';
import { Workbook, SpreadsheetFile } from '@oai/artifact-tool';

const root=path.resolve('solis-dealer-ecosystem-research');
const qa=path.join(root,'research','QA');
await fs.mkdir(qa,{recursive:true});
const access='2026-11-03';
const sources=[
{id:'F01',title:'International Tractors Limited Ratings reaffirmed',publisher:'ICRA',url:'https://www.icra.in/Rating/GetRationalReportFilePdf?id=139360',publication_date:'2025-11-28',access_date:access,classification:'Reported',claim:'ITL FY2024 and FY2025 financial indicators and Solis BV ownership',evidence:'Audited indicator table p4; export discussion p2; ownership annexure p6 reproduces company accounts.',limitations:'Rating agency reproduction, not underlying audited accounts. No Solis brand, Dutch or parts revenue split. Finance consolidation scope requires reconciliation.'},
{id:'F02',title:'AGCO 2025 Annual Report',publisher:'AGCO Corporation via SEC',url:'https://www.sec.gov/Archives/edgar/data/880266/000088026626000027/agco2025annualreport_ars.htm',publication_date:'2026; exact issue date not established',access_date:access,classification:'Verified',claim:'AGCO 2023 to 2025 revenue by product, and 2025 Europe Middle East parts sales',evidence:'Audited financial statements Disaggregated Revenue pp113 to115.',limitations:'Group and regional OEM sales; not Solis. Parts exclude separately unidentified services. G&P divestiture in November2024 changes denominator.'},
{id:'F03',title:'Titan Machinery FY2026 Form 10 K',publisher:'Titan Machinery via SEC',url:'https://www.sec.gov/Archives/edgar/data/1409171/000162828026022376/titn-20260131.htm',publication_date:'2026-03-31',access_date:access,classification:'Verified',claim:'Dealer revenue, gross profit and segment mix',evidence:'Year ended31 January2026; pp31 to33 and Note3 p62; amounts USD thousands.',limitations:'Multi-brand dealer group including construction, Europe and Australia. Retail vs OEM economics differ. Service gross profit definition differs from parts.'},
{id:'F04',title:'CNH 2025 Form 10 K',publisher:'CNH via SEC',url:'https://www.sec.gov/Archives/edgar/data/1567094/000156709426000006/cnhi-20251231.htm',publication_date:'2026; exact filing date not established',access_date:access,classification:'Verified',claim:'CNH segment net sales and aftersales business relevance',evidence:'Parts and Services pp10 to11; segment net sales pp49 to50.',limitations:'Reviewed disclosure does not isolate parts revenue; do not infer parts share from Agriculture total.'},
{id:'F05',title:'Deere and Company FY2025 Form 10 K',publisher:'Deere and Company via SEC',url:'https://www.sec.gov/Archives/edgar/data/315189/000110465925122321/de-20251102x10k.htm',publication_date:'2025-12-18',access_date:access,classification:'Verified',claim:'Equipment operations net sales include service parts and technology',evidence:'Item1 Equipment Operations and Note27 Segment Data.',limitations:'No isolated comparable parts percentage found in reviewed revenue and segment disclosures. FY ends2 November2025.'},
{id:'F06',title:'Financial Results for the Year Ended December 31 2025 IFRS',publisher:'Kubota Corporation',url:'https://www.kubota.com/ir/financial/release/data/136q4e.pdf',publication_date:'2026-02-12',access_date:access,classification:'Verified',claim:'Kubota group and Machinery 2025 revenue',evidence:'Earnings release p1 and segment/product tables.',limitations:'Parts revenue not isolated in reviewed release. Earnings release rather than audited annual statement.'}
];
await fs.writeFile(path.join(root,'research','finance_sources.json'),JSON.stringify(sources,null,2));
const rows=[];
function add(entity,period,metric,value,unit,scope,source,location){rows.push({entity,period,metric,value,unit,scope,source,location});}
for(const [year,tractor,parts,machinery,grain,total] of [[2023,8711,1816,2822.8,1062.6,14412.4],[2024,7059.3,1827.8,1942.3,832.5,11661.9],[2025,6693,1873.3,1514.4,1.3,10082]]){
  for(const [metric,value] of [['Tractors',tractor],['Replacement parts',parts],['Other machinery',machinery],['Grain systems',grain],['Net sales',total]])add('AGCO',year,metric,value,'USD million','Consolidated','F02',`Disaggregated Revenue p${year===2025?'113':year===2024?'114':'115'}`);
}
add('AGCO',2025,'Replacement parts',1227.6,'USD million','Europe Middle East','F02','Disaggregated Revenue p113');
add('AGCO',2025,'Net sales',6736.7,'USD million','Europe Middle East','F02','Disaggregated Revenue p113');
for(const [year,oi,pat,sop] of [[2024,9485.4,1740.3,9352.5],[2025,10021.8,1780.9,9789.7]]){
 add('ITL',year,'Operating income',oi,'INR crore','Consolidated as labelled by ICRA','F01','Audited indicators p4');
 add('ITL',year,'Profit after tax',pat,'INR crore','Consolidated as labelled by ICRA','F01','Audited indicators p4');
 add('ITL',year,'Operating income',sop,'INR crore','Standalone','F01','Audited indicators p4');
}
for(const [metric,value] of [['Equipment revenue',1774535],['Parts revenue',428261],['Service revenue',177910],['Rental and other revenue',46401],['Total revenue',2427107],['Equipment gross profit',129330],['Parts gross profit',132515],['Service gross profit',109459],['Rental and other gross profit',11252],['Total gross profit',382556]])add('Titan Machinery','FY2026',metric,value,'USD thousand','Consolidated dealer group','F03','10 K pp31 to33');
for(const [metric,value] of [['Equipment revenue',1135501],['Parts revenue',286927],['Service revenue',127186],['Rental and other revenue',8200],['Total revenue',1557814]])add('Titan Machinery','FY2026',metric,value,'USD thousand','Agriculture segment','F03','10 K Note3 p62 and segment note');
add('CNH',2025,'Net sales',12390,'USD million','Agriculture','F04','10 K p50');
add('CNH',2025,'Net sales',15346,'USD million','Industrial Activities','F04','10 K p49');
add('Deere','FY2025','Net sales',38917,'USD million','Equipment operations','F05','10 K Note27');
add('Kubota',2025,'Revenue',3018891,'JPY million','Consolidated','F06','Earnings release p1');
add('Kubota',2025,'Revenue',2628618,'JPY million','Machinery','F06','Segment and product table');
const scenarios=[
 {name:'Low',minutes:5,adoption:0.3,volume:1000,hourly_cost:35,return_rate:0.08,return_reduction:0.01,return_cost:40},
 {name:'Base',minutes:10,adoption:0.6,volume:1000,hourly_cost:35,return_rate:0.08,return_reduction:0.02,return_cost:40},
 {name:'High',minutes:15,adoption:0.8,volume:1000,hourly_cost:35,return_rate:0.08,return_reduction:0.03,return_cost:40}
].map(x=>({...x,capacity_hours:x.volume*x.adoption*x.minutes/60,capacity_equivalent:x.volume*x.adoption*x.minutes/60*x.hourly_cost,avoided_returns:x.volume*x.adoption*x.return_reduction,nonlabour_returns_value:x.volume*x.adoption*x.return_reduction*x.return_cost,gross_opportunity_equivalent:x.volume*x.adoption*x.minutes/60*x.hourly_cost+x.volume*x.adoption*x.return_reduction*x.return_cost}));
await fs.writeFile(path.join(root,'research','financial_data.json'),JSON.stringify({access_date:access,actuals:rows,scenarios,scenario_limitations:'Illustrative per1000 eligible annual requests; not Solis data, cash savings, cost or ROI forecast.'},null,2));
const esc=x=>'"'+String(x??'').replaceAll('"','""')+'"';
await fs.writeFile(path.join(root,'Financial_Analysis.csv'),[Object.keys(rows[0]).join(','),...rows.map(x=>Object.values(x).map(esc).join(','))].join('\r\n'));

const wb=Workbook.create();
const out=wb.worksheets.add('Financial analysis');
const model=wb.worksheets.add('Solis model');
const input=wb.worksheets.add('Source data');
const dark='#18384F',light='#EAF0F4',blue='#0000FF',green='#008000',amber='#FFF2CC';
const num='#,##0.0;(#,##0.0);"–"';
function setup(s,range){s.showGridLines=false;s.getRange(range).format.font={name:'Arial',size:10,color:'#18232C'};s.getRange(range).format.verticalAlignment='center';s.getRange(range).format.rowHeight=23;s.tabColor=dark;}
function title(s,cell,text){s.getRange(cell).values=[[text]];s.getRange(cell).format.font={name:'Arial',size:15,bold:true,color:'#000000'};s.getRange(cell).format.rowHeight=31;}
function head(s,range){s.getRange(range).format={fill:dark,font:{name:'Arial',size:10,color:'#FFFFFF',bold:true},rowHeight:29,horizontalAlignment:'center',verticalAlignment:'center',wrapText:true};}
function note(s,cell,text){s.getRange(cell).values=[[text]];s.getRange(cell).format.font={name:'Arial',size:10,italic:true,color:'#526371'};}
function form(s,cell,f,cross=false){s.getRange(cell).formulas=[[f]];s.getRange(cell).format.font.color=cross?green:'#000000';}
setup(input,'A1:J50');input.tabColor='#D7C5A5';
title(input,'A2','Financial source data');
input.getRange('A4:J4').values=[['Entity','Fiscal period','Metric','Value','Units','Scope','Source ID','Location',null,'Original source']];head(input,'A4:H4');head(input,'J4');
const map=new Map();
rows.forEach((r,i)=>{const rn=i+5;input.getRange(`A${rn}:H${rn}`).values=[[r.entity,r.period,r.metric,r.value,r.unit,r.scope,r.source,r.location]];map.set([r.entity,r.period,r.metric,r.scope].join('|'),rn);const src=sources.find(s=>s.id===r.source);input.getRange(`J${rn}`).values=[[src.url]];if(i%2===0)input.getRange(`A${rn}:H${rn}`).format.fill='#F4F6F8';});
input.getRange('D5:D50').setNumberFormat(num);input.getRange('D5:D50').format.font.color=blue;
for(const [col,width] of [['A',22],['B',14],['C',28],['D',16],['E',16],['F',37],['G',12],['H',36],['I',3],['J',123]])input.getRange(`${col}1:${col}50`).format.columnWidth=width;
input.freezePanes.freezeRows(4);input.getRange('B5:B50').format.horizontalAlignment='center';
function ref(entity,period,metric,scope){const rn=map.get([entity,period,metric,scope].join('|'));if(!rn)throw new Error('Missing source '+[entity,period,metric,scope]);return `'Source data'!D${rn}`;}
setup(out,'B1:N51');title(out,'B2','Machines parts and aftersales evidence');
out.getRange('B1:B51').format.columnWidth=29;out.getRange('C1:F51').format.columnWidth=18;out.getRange('G1:G51').format.columnWidth=3;out.getRange('H1:N51').format.columnWidth=11;
note(out,'B4','Peer evidence only. No Solis revenue split or ROI was established. Accessed 3 November 2026.');
out.getRange('B6:F6').values=[['AGCO USD million',2023,2024,2025,'Definition']];head(out,'B6:F6');
const agMetrics=['Tractors','Replacement parts','Other machinery','Grain systems','Net sales'];
agMetrics.forEach((m,i)=>{const rn=7+i;out.getRange(`B${rn}`).values=[[m]];[2023,2024,2025].forEach((y,j)=>form(out,`${'CDE'[j]}${rn}`,'='+ref('AGCO',y,m,'Consolidated'),true));});
out.getRange('F7:F11').values=[['Tractor category'],['Parts only'],['Combines and others'],['G&P business'],['Group denominator']];out.getRange('C7:E11').setNumberFormat(num);
out.getRange('B13').values=[['Parts share of net sales']];out.getRange('B14').values=[['Products less total']];for(const c of ['C','D','E']){form(out,`${c}13`,`=${c}8/${c}11`);form(out,`${c}14`,`=SUM(${c}7:${c}10)-${c}11`);}out.getRange('C13:E13').setNumberFormat('0.0%');out.getRange('C14:E14').setNumberFormat('0.00');out.getRange('B13:E13').format.font.italic=true;
out.getRange('B16:F16').values=[['Titan FY2026 USD m','Revenue','Gross profit','Revenue share','GP share']];head(out,'B16:F16');
const titMetrics=['Equipment','Parts','Service','Rental and other'];
titMetrics.forEach((m,i)=>{const r=17+i;out.getRange(`B${r}`).values=[[m]];form(out,`C${r}`,'='+ref('Titan Machinery','FY2026',m+' revenue','Consolidated dealer group')+'/1000',true);form(out,`D${r}`,'='+ref('Titan Machinery','FY2026',m+' gross profit','Consolidated dealer group')+'/1000',true);form(out,`E${r}`,`=C${r}/$C$21`);form(out,`F${r}`,`=D${r}/$D$21`);});
out.getRange('B21').values=[['Total']];form(out,'C21','=SUM(C17:C20)');form(out,'D21','=SUM(D17:D20)');form(out,'E21','=SUM(E17:E20)');form(out,'F21','=SUM(F17:F20)');out.getRange('B21:F21').format.font.bold=true;
out.getRange('C17:D21').setNumberFormat('#,##0.000;(#,##0.000);"–"');out.getRange('E17:F21').setNumberFormat('0.0%');
out.getRange('B23').values=[['Parts and service combined']];form(out,'E23','=SUM(E18:E19)');form(out,'F23','=SUM(F18:F19)');out.getRange('E23:F23').setNumberFormat('0.0%');
note(out,'B25','Titan is a retail dealer group. Gross profit precedes operating costs. Service cost definitions differ.');
out.getRange('B27:F27').values=[['ITL INR crore',2024,2025,'Change','Scope']];head(out,'B27:F27');
['Operating income','Profit after tax'].forEach((m,i)=>{let r=28+i;out.getRange(`B${r}`).values=[[m]];for(const [c,y] of [['C',2024],['D',2025]])form(out,`${c}${r}`,'='+ref('ITL',y,m,'Consolidated as labelled by ICRA'),true);form(out,`E${r}`,`=D${r}/C${r}-1`);out.getRange(`F${r}`).values=[['ICRA consolidated']];});out.getRange('C28:D29').setNumberFormat(num);out.getRange('E28:E29').setNumberFormat('0.0%');
note(out,'B31','ICRA reproduces audited indicators. Underlying ITL accounts and finance consolidation need confirmation.');
note(out,'B33','AGCO 2024 G&P disposal changes the group denominator. Rising parts share does not prove digital impact.');
out.getRange('B36:C39').values=[['Year','AGCO parts share'],[2023,null],[2024,null],[2025,null]];head(out,'B36:C36');form(out,'C37','=C13');form(out,'C38','=D13');form(out,'C39','=E13');out.getRange('C37:C39').setNumberFormat('0.0%');
const chart=out.charts.add('line',out.getRange('B36:C39'));chart.title='AGCO parts share of group net sales';chart.titleTextStyle.typeface='Arial';chart.titleTextStyle.fontSize=13;chart.hasLegend=false;chart.xAxis={axisType:'textAxis',textStyle:{typeface:'Arial',fontSize:10}};chart.yAxis={numberFormatCode:'0%',numberFormatSourceLinked:false,textStyle:{typeface:'Arial',fontSize:10}};chart.series.items[0].line={fill:'#237DA3',style:'solid',width:2};chart.setPosition('H6','N21');
note(out,'B42','CNH Deere and Kubota reviewed disclosures do not isolate a comparable parts percentage.');
note(out,'B44','Source data keeps units and reporting scopes intact. No exchange conversion is used.');
out.getRange('C14:E14').conditionalFormats.addCustom('ABS(C14)>0.005',{fill:'#FDE9E7',font:{color:'#9C0006',bold:true}});

setup(model,'B1:H54');model.tabColor='#5D829A';title(model,'B2','Solis business case framework');
model.getRange('B1:B54').format.columnWidth=40;model.getRange('C1:C54').format.columnWidth=20;model.getRange('D1:D54').format.columnWidth=21;model.getRange('E1:G54').format.columnWidth=14;model.getRange('H1:H54').format.columnWidth=3;
model.getRange('B4').values=[['Case Selected:']];model.getRange('C4').values=[[2]];model.getRange('C4').dataValidation={rule:{type:'whole',operator:'between',formula1:1,formula2:3}};model.getRange('C4').format.fill=amber;model.getRange('C4').format.font.color=blue;form(model,'D4','=CHOOSE(C4,"Low","Base","High")');model.getRange('D4').format.font.color=green;
note(model,'B6','1 Low  2 Base  3 High. All drivers below are illustrative assumptions, not Solis forecasts.');
model.getRange('B8:G8').values=[['Assumption','Active Selection','Unit','Low','Base','High']];head(model,'B8:G8');
const drivers=[['Eligible requests',1000,'annual requests',1000,1000,1000],['Minutes saved per adopted request',10,'minutes',5,10,15],['Adoption',0.6,'share',0.3,0.6,0.8],['Loaded hourly cost',35,'EUR per hour',35,35,35],['Baseline wrong part return rate',0.08,'share',0.08,0.08,0.08],['Reduction in return rate',0.02,'percentage points',0.01,0.02,0.03],['Avoidable non labour return cost',40,'EUR per return',40,40,40]];
drivers.forEach((r,i)=>{const n=9+i;model.getRange(`B${n}:G${n}`).values=[[r[0],null,r[2],r[3],r[4],r[5]]];form(model,`C${n}`,`=IF(INDEX(E${n}:G${n},1,$C$4)="","n.a.",INDEX(E${n}:G${n},1,$C$4))`);});
model.getRange('E9:G15').format.fill=amber;model.getRange('E9:G15').format.font.color=blue;model.getRange('C9:C15').format.fill=light;model.getRange('C9:C15').format.font.bold=true;
for(const r of [11,13,14]){model.getRange(`C${r}`).setNumberFormat('0.0%');model.getRange(`E${r}:G${r}`).setNumberFormat('0.0%');}model.getRange('C4').format.horizontalAlignment='center';
model.getRange('B17:D17').values=[['Illustrative annual build','Result','Unit']];head(model,'B17:D17');
const builds=[
['Adopted requests','=C9*C11','requests'],
['Capacity released','=C18*C10/60','hours'],
['Capacity equivalent','=C19*C12','EUR'],
['Return rate among adopted requests','=MAX(0,C13-C14)','share'],
['Avoided returns','=C18*MIN(C13,C14)','returns'],
['Non labour return cost avoided','=C22*C15','EUR'],
['Gross opportunity equivalent','=SUM(C20,C23)','EUR'],
['Per additional minute saved','=C18/60*C12','EUR'],
['Per additional percentage point','=C18*1%*C15','EUR']];
builds.forEach((r,i)=>{const n=18+i;model.getRange(`B${n}`).values=[[r[0]]];form(model,`C${n}`,`=IF(COUNT(C9:C15)<7,"n.a.",${r[1].slice(1)})`);model.getRange(`D${n}`).values=[[r[2]]];});model.getRange('C18:C26').setNumberFormat('#,##0.0;(#,##0.0);"–"');model.getRange('C18:C26').format.horizontalAlignment='right';model.getRange('C21').setNumberFormat('0.0%');model.getRange('B24:D24').format.font.bold=true;
note(model,'B28','Gross opportunity excludes implementation and run costs. Capacity value is not cash savings.');
note(model,'B30','Example assumes one eligible parts order per request. Return cost excludes labour counted above.');
model.getRange('B33:D33').values=[['Actual Solis inputs needed','Input','Unit']];head(model,'B33:D33');
const actuals=[['Eligible annual requests',null,'requests'],['Adoption observed',null,'share'],['Minutes saved observed',null,'minutes'],['Loaded hourly cost verified',null,'EUR per hour'],['Return rate reduction observed',null,'percentage points'],['Non labour cost avoided per return',null,'EUR per return'],['Annual run and change costs',null,'EUR']];model.getRange('B34:D40').values=actuals;model.getRange('C34:C40').format.fill=amber;model.getRange('C34:C40').format.font.color=blue;model.getRange('C35').setNumberFormat('0.0%');model.getRange('C38').setNumberFormat('0.0%');
model.getRange('B42').values=[['Actual annual capacity hours']];form(model,'C42','=IF(COUNT(C34:C36)<3,"n.a.",C34*C35*C36/60)');
model.getRange('B43').values=[['Actual capacity equivalent EUR']];form(model,'C43','=IF(COUNT(C34:C37)<4,"n.a.",C42*C37)');
model.getRange('B44').values=[['Actual non labour return saving EUR']];form(model,'C44','=IF(OR(COUNT(C34:C35)<2,COUNT(C38:C39)<2),"n.a.",C34*C35*C38*C39)');
model.getRange('B45').values=[['Gross opportunity less run costs EUR']];form(model,'C45','=IF(OR(COUNT(C43:C44)<2,COUNT(C40)<1),"n.a.",SUM(C43:C44)-C40)');
model.getRange('B47').values=[['Required inputs still missing']];form(model,'C47','=7-COUNT(C34:C40)');model.getRange('C42:C47').format.horizontalAlignment='right';
model.getRange('C47').conditionalFormats.add('cellIs',{operator:'greaterThan',formula:0,format:{fill:'#FDE9E7',font:{color:'#9C0006',bold:true}}});
note(model,'B49','ROI and payback need approved implementation cost and cash timing. Neither is invented here.');
note(model,'B51','Blue amber cells are editable inputs. Actual input blanks display n.a. A measured zero remains zero.');

wb.recalculate();
const cases=[];
for(const c of [1,2,3]){model.getRange('C4').values=[[c]];wb.recalculate();const vals=model.getRange('C18:C26').values.flat();cases.push({case:c,values:vals});const expected=scenarios[c-1];if(Math.abs(vals[6]-expected.gross_opportunity_equivalent)>1e-8)throw new Error('Scenario mismatch '+c);}
model.getRange('C4').values=[[2]];
model.getRange('E10').clear({applyTo:'contents'});wb.recalculate();if(model.getRange('C19').values[0][0]!==100)throw new Error('Unselected blank blocked base');model.getRange('C4').values=[[1]];wb.recalculate();if(model.getRange('C19').values[0][0]!=='n.a.')throw new Error('Selected blank masked');model.getRange('E10').values=[[5]];model.getRange('C4').values=[[2]];
model.getRange('F10').values=[[11]];wb.recalculate();if(model.getRange('C19').values[0][0]!==110)throw new Error('Driver sensitivity failed');model.getRange('F10').values=[[10]];
model.getRange('C34').values=[[1000]];wb.recalculate();if(model.getRange('C42').values[0][0]!=='n.a.')throw new Error('Missing inputs masked');model.getRange('C35:C36').values=[[0],[10]];wb.recalculate();if(model.getRange('C42').values[0][0]!==0)throw new Error('Valid zero failed');model.getRange('C34:C36').clear({applyTo:'contents'});
wb.recalculate();
const inspections=[];
for(const range of ['Financial analysis!B6:F29','Solis model!B8:G26','Solis model!B33:D47'])inspections.push((await wb.inspect({kind:'table',range,include:'values,formulas',tableMaxRows:26,tableMaxCols:6,maxChars:15000})).ndjson);
const err=(await wb.inspect({kind:'match',searchTerm:'#REF!|#DIV/0!|#VALUE!|#NAME\\?|#N/A|#NUM!|#NULL!|#SPILL!|#CALC!',options:{useRegex:true,maxResults:100},summary:'Final formula error scan'})).ndjson;
await fs.writeFile(path.join(qa,'financial_checks.json'),JSON.stringify({scenario_checks:cases,inspections,error_scan:err,checks:['Scenario selector changes the same build','One minute change recalculates output','Missing actual inputs remain unavailable','Zero adoption returns valid zero','Source actuals remain unchanged']},null,2));
for(const [sheetName,range,name] of [['Financial analysis','B2:N44','financial_analysis.png'],['Solis model','B2:G30','solis_model.png'],['Solis model','B33:G51','solis_actual_inputs.png'],['Source data','A2:H26','financial_sources_1.png'],['Source data','A27:H48','financial_sources_2.png'],['Source data','J4:J10','financial_source_urls.png']]){const img=await wb.render({sheetName,range,scale:1.5,format:'png'});await fs.writeFile(path.join(qa,name),new Uint8Array(await img.arrayBuffer()));}
const xlsx=await SpreadsheetFile.exportXlsx(wb);await xlsx.save(path.join(root,'Financial_Analysis.xlsx'));
console.log(JSON.stringify({workbook:path.join(root,'Financial_Analysis.xlsx'),actuals:rows.length,cases,error_scan:err}));
